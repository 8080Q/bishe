DROP TABLE IF EXISTS `classification_of_scenic_spots`;
CREATE TABLE `classification_of_scenic_spots`(
	   `classification_of_scenic_spots_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '景点分类ID',
`scenic_spot_category` varchar(64) comment '景点类别',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
 `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

	   PRIMARY KEY (classification_of_scenic_spots_id)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '景点分类';
insert into `classification_of_scenic_spots` values (1,'景点类别1','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (2,'景点类别2','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (3,'景点类别3','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (4,'景点类别4','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (5,'景点类别5','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (6,'景点类别6','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (7,'景点类别7','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `classification_of_scenic_spots` values (8,'景点类别8','0','2022-04-02 10:18:15','2022-04-02 10:18:15');

DROP TABLE IF EXISTS `registered_user`;
CREATE TABLE `registered_user`(
	   `registered_user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '注册用户ID',
`user_name` varchar(64) NOT NULL UNIQUE comment '用户名',
`examine_state` varchar(16) DEFAULT '已通过' NOT NULL comment '审核状态',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`user_id` int(11) DEFAULT '0' NOT NULL comment '用户ID',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
 `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

	   PRIMARY KEY (registered_user_id)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '注册用户';

DROP TABLE IF EXISTS `hotel_management`;
CREATE TABLE `hotel_management`(
	   `hotel_management_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '酒店管理ID',
`hotel_number` varchar(64) comment '酒店编号',
`hotel_name` varchar(64) comment '酒店名称',
`layout_of_a_house_or_an_apartment` varchar(64) comment '房型',
`price` int(11) DEFAULT 0 comment '价格',
`photo` varchar(255) comment '照片',
`address` varchar(64) comment '地址',
`amenities` text comment '便利设施',
`traffic_guide` text comment '交通指南',
`hotel_introduction` longtext comment '酒店介绍',
`hits` int(11) DEFAULT 0 NOT NULL comment '点击数',
`praise_len` int(11) DEFAULT 0 NOT NULL comment '点赞数',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
 `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

	   PRIMARY KEY (hotel_management_id)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '酒店管理';
insert into `hotel_management` values (1,'酒店编号1','酒店名称1','房型1',5,'/api/upload/image_1642315548266.jpg','地址1','便利设施1','交通指南1','此处可上传文字、图片、视频、超链接、表格等内容区1','783','225','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (2,'酒店编号2','酒店名称2','房型2',10,'/api/upload/image_1642315548262.jpg','地址2','便利设施2','交通指南2','此处可上传文字、图片、视频、超链接、表格等内容区2','396','484','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (3,'酒店编号3','酒店名称3','房型3',15,'/api/upload/image_1642315548308.jpg','地址3','便利设施3','交通指南3','此处可上传文字、图片、视频、超链接、表格等内容区3','299','419','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (4,'酒店编号4','酒店名称4','房型4',20,'/api/upload/image_1642315548309.jpg','地址4','便利设施4','交通指南4','此处可上传文字、图片、视频、超链接、表格等内容区4','707','318','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (5,'酒店编号5','酒店名称5','房型5',25,'/api/upload/image_1642315548254.jpg','地址5','便利设施5','交通指南5','此处可上传文字、图片、视频、超链接、表格等内容区5','835','383','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (6,'酒店编号6','酒店名称6','房型6',30,'/api/upload/image_1642315548266.jpg','地址6','便利设施6','交通指南6','此处可上传文字、图片、视频、超链接、表格等内容区6','850','203','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (7,'酒店编号7','酒店名称7','房型7',35,'/api/upload/image_1642315548308.jpg','地址7','便利设施7','交通指南7','此处可上传文字、图片、视频、超链接、表格等内容区7','274','222','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `hotel_management` values (8,'酒店编号8','酒店名称8','房型8',40,'/api/upload/image_1642315548309.jpg','地址8','便利设施8','交通指南8','此处可上传文字、图片、视频、超链接、表格等内容区8','246','855','0','2022-04-02 10:18:15','2022-04-02 10:18:15');

DROP TABLE IF EXISTS `room_type_management`;
CREATE TABLE `room_type_management`(
	   `room_type_management_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '房型管理ID',
`layout_of_a_house_or_an_apartment` varchar(64) comment '房型',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
 `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

	   PRIMARY KEY (room_type_management_id)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '房型管理';
insert into `room_type_management` values (1,'房型1','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (2,'房型2','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (3,'房型3','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (4,'房型4','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (5,'房型5','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (6,'房型6','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (7,'房型7','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `room_type_management` values (8,'房型8','0','2022-04-02 10:18:15','2022-04-02 10:18:15');

DROP TABLE IF EXISTS `tourist_route`;
CREATE TABLE `tourist_route`(
	   `tourist_route_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '旅游路线ID',
`route_travel` varchar(64) comment '路线行程',
`scenic_spot_category` varchar(64) comment '景点类别',
`days` varchar(64) comment '天数',
`cover` varchar(255) comment '封面',
`price` int(11) DEFAULT 0 comment '价格',
`cost_includes` text comment '费用包含',
`traffic_strategy` text comment '交通攻略',
`accommodation_strategy` text comment '住宿攻略',
`food_introduction` text comment '美食攻略',
`route_introduction` longtext comment '路线介绍',
`hits` int(11) DEFAULT 0 NOT NULL comment '点击数',
`praise_len` int(11) DEFAULT 0 NOT NULL comment '点赞数',
`recommend` int(11) DEFAULT '0' NOT NULL comment '智能推荐',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
 `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

	   PRIMARY KEY (tourist_route_id)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8 comment '旅游路线';
insert into `tourist_route` values (1,'路线行程1','景点类别1','天数1','/api/upload/image_1615206273485.jpg',5,'费用包含1','交通攻略1','住宿攻略1','美食攻略1','此处可上传文字、图片、视频、超链接、表格等内容区1','13','291','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (2,'路线行程2','景点类别2','天数2','/api/upload/image_1615206273513.jpg',10,'费用包含2','交通攻略2','住宿攻略2','美食攻略2','此处可上传文字、图片、视频、超链接、表格等内容区2','317','60','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (3,'路线行程3','景点类别3','天数3','/api/upload/image_1615198958415.jpg',15,'费用包含3','交通攻略3','住宿攻略3','美食攻略3','此处可上传文字、图片、视频、超链接、表格等内容区3','110','754','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (4,'路线行程4','景点类别4','天数4','/api/upload/image_1615206273491.jpg',20,'费用包含4','交通攻略4','住宿攻略4','美食攻略4','此处可上传文字、图片、视频、超链接、表格等内容区4','745','913','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (5,'路线行程5','景点类别5','天数5','/api/upload/image_1615206273499.jpg',25,'费用包含5','交通攻略5','住宿攻略5','美食攻略5','此处可上传文字、图片、视频、超链接、表格等内容区5','19','794','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (6,'路线行程6','景点类别6','天数6','/api/upload/image_1615206273494.jpg',30,'费用包含6','交通攻略6','住宿攻略6','美食攻略6','此处可上传文字、图片、视频、超链接、表格等内容区6','311','69','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (7,'路线行程7','景点类别7','天数7','/api/upload/image_1615198957362.jpg',35,'费用包含7','交通攻略7','住宿攻略7','美食攻略7','此处可上传文字、图片、视频、超链接、表格等内容区7','127','638','0','2022-04-02 10:18:15','2022-04-02 10:18:15');
insert into `tourist_route` values (8,'路线行程8','景点类别8','天数8','/api/upload/image_1615198969403.jpg',40,'费用包含8','交通攻略8','住宿攻略8','美食攻略8','此处可上传文字、图片、视频、超链接、表格等内容区8','169','933','0','2022-04-02 10:18:15','2022-04-02 10:18:15');

DROP TABLE IF EXISTS `access_token`;
CREATE TABLE `access_token` (
  `token_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '临时访问牌ID',
  `token` varchar(64) DEFAULT NULL COMMENT '临时访问牌',
  `info` text,
  `maxage` int(2) NOT NULL DEFAULT '2' COMMENT '最大寿命：默认2小时',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户编号:',
  PRIMARY KEY (`token_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='临时访问牌';
insert into `access_token` values ('57','5accf85cb6a7f06f0aa2968deadaec1b',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('58','46ff1d4d07714f046ba07b34bffe0af9',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('59','ed9d6cba9826fda1beafcd9326be7a86',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('60','c99763c1833ea0785d9e2b81da3fd28f',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('61','33fbfaccd6d1cb9143e4129bd919d4b0',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('62','493e13da5f293ba67a56a0fe3e1fa6cf',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('63','c4b48e9e2160db09c703041a8fee0a1f',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('64','d13cdaefd3823c360c959a02a262f71d',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('65','6c6ff426fd77ea5a2025ce5ed2e42c8a',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('66','80930065a61ffcdd5cbb75f60932973c',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('67','94114763cf2e3b020495d8a27096d4ef',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('68','761052c551c97c9317bc3aa475c85b84',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('69','7c44ef14131a0ba7c16aa16cef104065',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('70','96380f3d9542c80d04bdade1cf7635a5',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('71','bfdc7acfcbf5763fda81945b60961222',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('72','170a598e51ae8ae2badde20a42fe171d',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('73','c82c357488c75926a92d8a9608d4b367',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('74','4d35290c023f407a820f37dbbb1ceb09',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('75','8d19162776682b695c0f62f3c7a92fec',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('76','a7ea2cdc9a2be179e19200e593ad5a69',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('77','c79a554f9832adc01f19682c5d576bc4',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('78','1c7d95001fa09951a679841c8100ad1f',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('79','776da1bcdd01ddb3cbf0a37fa13fc5b0',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('80','d336e88e57c329d0166931292c1fac41',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('81','37a40f526a6c82fc6110b512802d35bf',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('82','691ad331771f4109206d58aeee572371',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('83','9942e458886219960d3344b4a6a6fbec',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('84','e9939a8b7ccf9f548f0bbb5664981f96',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('85','f5b27912060d1909bef61fab9d96faae',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('86','7c5888682f1d449eb1b62f0054a79fbf',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('87','00dfdc6ac21c4a9da80fd71c990764d1',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('88','3cce592bc72840ab932ce96d85a194da',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('89','43fdaa989a644ad683ef4b4d488e8629',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('90','d6a3cecadacff0dbd6b43b25372cc2a2',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('91','5570bc5b07b3589f4ef8553bd46eb0d1',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('92','5570bc5b07b3589f4ef8553bd46eb0d1',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('93','26c553bd2ee2ab6605d18dfd310d85f9',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('94','3fd52f81236ed2c37ff91a6696d4e47a',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('95','893332e9ee67d60d8312b3700c58a359',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('96','b7844068ade535b2e517df4a40948703',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('97','179b37a5e1893c3af6b946bd5a1c8625',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('98','3a47b8a040a83ebbc9194cb255dc668c',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('99','afa60196afb77dcc2b520ed13a817560',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
insert into `access_token` values ('100','7fc6d9b324f8c0a3a1784d04ef132692',null,'2',"2022-01-14 07:32:09.000 ","2022-01-14 07:32:09.000 ",'1');
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `article_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章id：[0,8388607]',
  `title` varchar(125) NOT NULL DEFAULT '' COMMENT '标题：[0,125]用于文章和html的title标签中',
  `type` varchar(64) NOT NULL DEFAULT '0' COMMENT '文章分类：[0,1000]用来搜索指定类型的文章',
  `hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点击数：[0,1000000000]访问这篇文章的人次',
  `praise_len` int(11) NOT NULL DEFAULT '0' COMMENT '点赞数',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source` varchar(255) DEFAULT NULL COMMENT '来源：[0,255]文章的出处',
  `url` varchar(255) DEFAULT NULL COMMENT '来源地址：[0,255]用于跳转到发布该文章的网站',
  `tag` varchar(255) DEFAULT NULL COMMENT '标签：[0,255]用于标注文章所属相关内容，多个标签用空格隔开',
  `content` longtext COMMENT '正文：文章的主体内容',
  `img` varchar(255) DEFAULT NULL COMMENT '封面图',
  `description` text COMMENT '文章描述',
  PRIMARY KEY (`article_id`,`title`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='文章：用于内容管理系统的文章';
DROP TABLE IF EXISTS `article_type`;
CREATE TABLE `article_type` (
  `type_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID：[0,10000]',
  `display` smallint(4) unsigned NOT NULL DEFAULT '100' COMMENT '显示顺序：[0,1000]决定分类显示的先后顺序',
  `name` varchar(16) NOT NULL DEFAULT '' COMMENT '分类名称：[2,16]',
  `father_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID：[0,32767]',
  `description` varchar(255) DEFAULT NULL COMMENT '描述：[0,255]描述该分类的作用',
  `icon` text COMMENT '分类图标：',
  `url` varchar(255) DEFAULT NULL COMMENT '外链地址：[0,255]如果该分类是跳转到其他网站的情况下，就在该URL上设置',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`type_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='文章频道：用于汇总浏览文章，在不同频道下展示不同文章。';
DROP TABLE IF EXISTS `auth`;
CREATE TABLE `auth` (
  `auth_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '授权ID：',
  `user_group` varchar(64) DEFAULT NULL COMMENT '用户组：',
  `mod_name` varchar(64) DEFAULT NULL COMMENT '模块名：',
  `table_name` varchar(64) DEFAULT NULL COMMENT '表名：',
  `page_title` varchar(255) DEFAULT NULL COMMENT '页面标题：',
  `path` varchar(255) DEFAULT NULL COMMENT '路由路径：',
  `position` varchar(32) DEFAULT NULL COMMENT '位置：',
  `mode` varchar(32) NOT NULL DEFAULT '_blank' COMMENT '跳转方式：',
  `add` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可增加：',
  `del` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可删除：',
  `set` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可修改：',
  `get` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否可查看：',
  `field_add` varchar(500) DEFAULT NULL COMMENT '添加字段：',
  `field_set` varchar(500) DEFAULT NULL COMMENT '修改字段：',
  `field_get` varchar(500) DEFAULT NULL COMMENT '查询字段：',
  `table_nav_name` varchar(255) DEFAULT NULL COMMENT '跨表导航名称：',
  `table_nav` varchar(255) DEFAULT NULL COMMENT '跨表导航：',
  `option` text COMMENT '配置：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`auth_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='定制授权';
DROP TABLE IF EXISTS `collect`;
CREATE TABLE `collect` (
  `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '收藏ID：',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏人ID：',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  `title` varchar(255) DEFAULT NULL COMMENT '标题：',
  `img` varchar(255) DEFAULT NULL COMMENT '封面：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`collect_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='收藏：';
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论人ID：',
  `reply_to_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '回复评论ID：空为0',
  `content` longtext COMMENT '内容：',
  `nickname` varchar(255) DEFAULT NULL COMMENT '昵称：',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像地址：[0,255]',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  PRIMARY KEY (`comment_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='评论：';
DROP TABLE IF EXISTS `forum`;
CREATE TABLE `forum` (
  `forum_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '论坛id',
  `display` smallint(5) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `nickname` varchar(16) DEFAULT '' COMMENT '昵称：[0,16]',
  `praise_len` int(10) unsigned DEFAULT '0' COMMENT '点赞数',
  `hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '访问数',
  `title` varchar(125) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(125) DEFAULT NULL COMMENT '关键词',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `url` varchar(255) DEFAULT NULL COMMENT '来源地址',
  `tag` varchar(255) DEFAULT NULL COMMENT '标签',
  `img` text COMMENT '封面图',
  `content` longtext COMMENT '正文',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `avatar` varchar(255) DEFAULT NULL COMMENT '发帖人头像：',
  `type` varchar(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '0' COMMENT '论坛分类：[0,1000]用来搜索指定类型的论坛帖',
  PRIMARY KEY (`forum_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='论坛：';
insert into `forum` values ('1','100','1','小明','0','149','测试标题','关键字1','描述','#','标签','/static/img/img_temp.jpg','<h1>fafgwagbagbwgwag</h1>',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'http://localhost:5000/upload/jingdian (11)_15.jpg','0');
insert into `forum` values ('2','100','2','小明','0','30','测试标题2','关键字2','dec','#','标签','/static/img/img_temp.jpg','测试文章内容2',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",null,'0');
insert into `forum` values ('3','100','2','小红','0','42','测试标题3','关键字3','dec2','#','标签','/static/img/img_temp.jpg','测试文章内容3',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",null,'0');
insert into `forum` values ('4','100','2','小红','0','22','测试标题4','关键字4','dec3','#','标签','/static/img/img_temp.jpg','测试文章内容4',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",null,'0');
DROP TABLE IF EXISTS `forum_type`;
CREATE TABLE `forum_type` (
  `type_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID：[0,10000]',
  `name` varchar(16) NOT NULL DEFAULT '' COMMENT '分类名称：[2,16]',
  `description` varchar(255) DEFAULT NULL COMMENT '描述：[0,255]描述该分类的作用',
  `url` varchar(255) DEFAULT NULL COMMENT '外链地址：[0,255]如果该分类是跳转到其他网站的情况下，就在该URL上设置',
  `father_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID：[0,32767]',
  `icon` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '分类图标：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`type_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='论坛频道：用于汇总浏览论坛，在不同频道下展示不同论坛。';
insert into `forum_type` values ('1','休闲','描述','/article/list?type_id=1','0',null,"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
insert into `forum_type` values ('2','娱乐','企业信息描述描述描述描述','/article/list?type_id=2','0',null,"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
insert into `forum_type` values ('3','开心','操作帮助描述描述描述','/article/list?type_id=3','0',null,"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `notice_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '公告id：',
  `title` varchar(125) NOT NULL DEFAULT '' COMMENT '标题：',
  `content` longtext COMMENT '正文：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`notice_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='公告：';
insert into `notice` values ('1','公告标题1','公告，是指政府、团体对重大事件当众正式公布或者公开宣告，宣布。国务院2012年4月16日发布、2012年7月1日起施行的《党政机关公文处理工作条例》，对公告的使用表述为：“适用于向国内外宣布重要事项或者法定事项”。其中包含两方面的内容：一是向国内外宣布重要事项，公布依据政策、法令采取的重大行动等；二是向国内外宣布法定事项，公布依据法律规定告知国内外的有关重要规定和重大行动等。',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
insert into `notice` values ('2','公告标题2','公告，包含两方面的内容：一是向国内外宣布重要事项，公布依据政策、法令采取的重大行动等；二是向国内外宣布法定事项，公布依据法律规定告知国内外的有关重要规定和重大行动等',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
insert into `notice` values ('3','公告标题3','公告，是指政府、团体对重大事件当众正式公布或者公开宣告，宣布。国务院2012年4月16日发布、2012年7月1日起施行的《党政机关公文处理工作条例》，对公告的使用表述为：“适用于向国内外宣布重要事项或者法定事项”。其中包含两方面的内容：一是向国内外宣布重要事项，公布依据政策、法令采取的重大行动等；二是向国内外宣布法定事项，公布依据法律规定告知国内外的有关重要规定和重大行动等。',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
insert into `notice` values ('4','公告标题4','公告，包含两方面的内容：一是向国内外宣布重要事项，公布依据政策、法令采取的重大行动等；二是向国内外宣布法定事项，公布依据法律规定告知国内外的有关重要规定和重大行动等',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ");
DROP TABLE IF EXISTS `praise`;
CREATE TABLE `praise` (
  `praise_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '点赞ID：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞人：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '点赞状态:1为点赞，0已取消',
  PRIMARY KEY (`praise_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='点赞：';
insert into `praise` values ('2','1',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','7','1');
insert into `praise` values ('25','5',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','9','1');
insert into `praise` values ('26','5',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','7','1');
insert into `praise` values ('27','5',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','7','1');
insert into `praise` values ('44','2',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'forum','forum_id','2','1');
insert into `praise` values ('50','2',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'forum','forum_id','2','1');
insert into `praise` values ('54','2',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','9','1');
insert into `praise` values ('57','0',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','10','1');
insert into `praise` values ('86','0',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','6','1');
insert into `praise` values ('101','7',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','7','1');
insert into `praise` values ('108','2',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','8','1');
insert into `praise` values ('221','0',"2022-04-19 07:32:09.000 ","2022-04-19 07:32:09.000 ",'article','article_id','2','1');
DROP TABLE IF EXISTS `slides`;
CREATE TABLE `slides` (
  `slides_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '轮播图ID：',
  `title` varchar(64) DEFAULT NULL COMMENT '标题：',
  `content` varchar(255) DEFAULT NULL COMMENT '内容：',
  `url` varchar(255) DEFAULT NULL COMMENT '链接：',
  `img` varchar(255) DEFAULT NULL COMMENT '轮播图：',
  `hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点击量：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`slides_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='轮播图：';
DROP TABLE IF EXISTS `upload`;
CREATE TABLE `upload` (
  `upload_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '上传ID',
  `name` varchar(64) DEFAULT NULL COMMENT '文件名',
  `path` varchar(255) DEFAULT NULL COMMENT '访问路径',
  `file` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `display` varchar(255) DEFAULT NULL COMMENT '显示顺序',
  `father_id` int(11) DEFAULT '0' COMMENT '父级ID',
  `dir` varchar(255) DEFAULT NULL COMMENT '文件夹',
  `type` varchar(32) DEFAULT NULL COMMENT '文件类型',
  PRIMARY KEY (`upload_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
insert into `upload` values ('1','movie.mp4','/upload/movie.mp4','',null,'0',null,'video');
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID：[0,8388607]用户获取其他与用户相关的数据',
  `state` smallint(1) unsigned NOT NULL DEFAULT '1' COMMENT '账户状态：[0,10](1可用|2异常|3已冻结|4已注销)',
  `user_group` varchar(32) DEFAULT NULL COMMENT '所在用户组：[0,32767]决定用户身份和权限',
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '上次登录时间：',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号码：[0,11]用户的手机号码，用于找回密码时或登录时',
  `phone_state` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机认证：[0,1](0未认证|1审核中|2已认证)',
  `username` varchar(16) NOT NULL DEFAULT '' COMMENT '用户名：[0,16]用户登录时所用的账户名称',
  `nickname` varchar(16) DEFAULT '' COMMENT '昵称：[0,16]',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '密码：[0,32]用户登录所需的密码，由6-16位数字或英文组成',
  `email` varchar(64) DEFAULT '' COMMENT '邮箱：[0,64]用户的邮箱，用于找回密码时或登录时',
  `email_state` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '邮箱认证：[0,1](0未认证|1审核中|2已认证)',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像地址：[0,255]',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户账户：用于保存用户登录信息';
insert into `user` values ('1','1','管理员',"2022-04-19 07:32:09.000 ",null,'0','admin','admin','bfd59291e825b5f2bbf1eb76569f8fe7','','0','/api/upload/avatar.jpg',"2022-04-19 07:32:09.000 ");
DROP TABLE IF EXISTS `user_group`;
CREATE TABLE `user_group` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组ID：[0,8388607]',
  `display` smallint(4) unsigned NOT NULL DEFAULT '100' COMMENT '显示顺序：[0,1000]',
  `name` varchar(16) NOT NULL DEFAULT '' COMMENT '名称：[0,16]',
  `description` varchar(255) DEFAULT NULL COMMENT '描述：[0,255]描述该用户组的特点或权限范围',
  `source_table` varchar(255) DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  `register` smallint(1) unsigned DEFAULT '0' COMMENT '注册位置:',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  PRIMARY KEY (`group_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户组：用于用户前端身份和鉴权';
DROP TABLE IF EXISTS `hits`;
CREATE TABLE `hits` (
  `hits_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '点赞ID：',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞人：',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间：',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间：',
  `source_table` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '来源表：',
  `source_field` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '来源字段：',
  `source_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源ID：',
  PRIMARY KEY (`hits_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
insert into `auth` values ('1','管理员','景点分类','classification_of_scenic_spots','景点分类','/classification_of_scenic_spots/table','','_blank','1','1','1','1','scenic_spot_category','scenic_spot_category','scenic_spot_category',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('2','管理员','景点分类','classification_of_scenic_spots','景点分类详情','/classification_of_scenic_spots/view','','_blank','1','1','1','1','scenic_spot_category','scenic_spot_category','scenic_spot_category',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('3','管理员','注册用户','registered_user','注册用户','/registered_user/table','','_blank','1','1','1','1','user_name','user_name','user_name',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('4','管理员','注册用户','registered_user','注册用户详情','/registered_user/view','','_blank','1','1','1','1','user_name','user_name','user_name',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('5','管理员','酒店管理','hotel_management','酒店管理','/hotel_management/table','','_blank','1','1','1','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{"can_show_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('6','管理员','酒店管理','hotel_management','酒店管理详情','/hotel_management/view','','_blank','1','1','1','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('7','管理员','酒店管理','hotel_management','酒店管理','/hotel_management/list','top','_blank','1','1','1','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('8','管理员','酒店管理','hotel_management','酒店管理详情','/hotel_management/details','','_blank','1','1','1','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('9','管理员','房型管理','room_type_management','房型管理','/room_type_management/table','','_blank','1','1','1','1','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('10','管理员','房型管理','room_type_management','房型管理详情','/room_type_management/view','','_blank','1','1','1','1','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('11','管理员','旅游路线','tourist_route','旅游路线','/tourist_route/table','','_blank','1','1','1','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{"can_show_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('12','管理员','旅游路线','tourist_route','旅游路线详情','/tourist_route/view','','_blank','1','1','1','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('13','管理员','旅游路线','tourist_route','旅游路线','/tourist_route/list','top','_blank','1','1','1','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('14','管理员','旅游路线','tourist_route','旅游路线详情','/tourist_route/details','','_blank','1','1','1','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('15','管理员','我的收藏','collect','我的收藏','/collect/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('16','管理员','评论','comment','评论列表','/comment/table','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('17','管理员','评论','comment','评论详情','/comment/view','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('18','管理员','评论','comment','我的评论','/comment/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('19','管理员','评论','comment','评论详情','/comment/details','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('20','管理员','论坛','forum','攻略交流','/forum/table','','_blank','1','1','1','1','','','',null,'0','{"print":true,"import_db":true,"export_db":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('21','管理员','论坛','forum','论坛详情','/forum/view','','_blank','1','1','1','1','','','',null,'0','{"print":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('22','管理员','论坛','forum','攻略交流','/forum/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('23','管理员','论坛','forum','论坛详情','/forum/details','','_blank','1','1','1','1','','','',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('24','管理员','论坛分类','forum_type','交流分类','/forum_type/table','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('25','管理员','论坛分类','forum_type','论坛分类详情','/forum_type/view','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('26','管理员','新闻','article','旅游资讯','/article/table','','_blank','1','1','1','1','','','',null,'0','{"print":true,"import_db":true,"export_db":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('27','管理员','新闻','article','新闻详情','/article/view','','_blank','1','1','1','1','','','',null,'0','{"print":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('28','管理员','新闻','article','旅游资讯','/article/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('29','管理员','新闻','article','新闻详情','/article/details','','_blank','1','1','1','1','','','',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('30','管理员','新闻分类','article_type','资讯分类','/article_type/table','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('31','管理员','新闻分类','article_type','新闻分类详情','/article_type/view','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('32','游客','景点分类','classification_of_scenic_spots','景点分类','/classification_of_scenic_spots/table','','_blank','0','0','0','0','scenic_spot_category','scenic_spot_category','scenic_spot_category',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('33','游客','景点分类','classification_of_scenic_spots','景点分类详情','/classification_of_scenic_spots/view','','_blank','0','0','0','0','scenic_spot_category','scenic_spot_category','scenic_spot_category',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('34','游客','注册用户','registered_user','注册用户','/registered_user/table','','_blank','1','0','0','0','user_name','user_name','user_name',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('35','游客','注册用户','registered_user','注册用户详情','/registered_user/view','','_blank','1','0','0','0','user_name','user_name','user_name',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('36','游客','酒店管理','hotel_management','酒店管理','/hotel_management/table','','_blank','0','0','0','0','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{"can_show_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('37','游客','酒店管理','hotel_management','酒店管理详情','/hotel_management/view','','_blank','0','0','0','0','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('38','游客','酒店管理','hotel_management','酒店管理','/hotel_management/list','top','_blank','0','0','0','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('39','游客','酒店管理','hotel_management','酒店管理详情','/hotel_management/details','','_blank','0','0','0','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{"can_show_comment":false,"can_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('40','游客','房型管理','room_type_management','房型管理','/room_type_management/table','','_blank','0','0','0','0','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('41','游客','房型管理','room_type_management','房型管理详情','/room_type_management/view','','_blank','0','0','0','0','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('42','游客','旅游路线','tourist_route','旅游路线','/tourist_route/table','','_blank','0','0','0','0','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{"can_show_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('43','游客','旅游路线','tourist_route','旅游路线详情','/tourist_route/view','','_blank','0','0','0','0','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('44','游客','旅游路线','tourist_route','旅游路线','/tourist_route/list','top','_blank','0','0','0','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('45','游客','旅游路线','tourist_route','旅游路线详情','/tourist_route/details','','_blank','0','0','0','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{"can_show_comment":false,"can_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('46','游客','我的收藏','collect','我的收藏','/collect/list','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('47','游客','评论','comment','评论列表','/comment/table','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('48','游客','评论','comment','评论详情','/comment/view','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('49','游客','评论','comment','我的评论','/comment/list','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('50','游客','评论','comment','评论详情','/comment/details','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('51','游客','论坛','forum','论坛列表','/forum/table','','_blank','0','0','0','0','','','',null,'0','{"print":false,"import_db":false,"export_db":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('52','游客','论坛','forum','论坛详情','/forum/view','','_blank','0','0','0','0','','','',null,'0','{"print":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('53','游客','论坛','forum','攻略交流','/forum/list','','_blank','0','0','0','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('54','游客','论坛','forum','论坛详情','/forum/details','','_blank','0','0','0','1','','','',null,'0','{"can_show_comment":false,"can_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('55','游客','论坛分类','forum_type','论坛分类列表','/forum_type/table','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('56','游客','论坛分类','forum_type','论坛分类详情','/forum_type/view','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('57','游客','新闻','article','新闻列表','/article/table','','_blank','0','0','0','0','','','',null,'0','{"print":false,"import_db":false,"export_db":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('58','游客','新闻','article','新闻详情','/article/view','','_blank','0','0','0','0','','','',null,'0','{"print":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('59','游客','新闻','article','旅游资讯','/article/list','','_blank','0','0','0','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('60','游客','新闻','article','新闻详情','/article/details','','_blank','0','0','0','1','','','',null,'0','{"can_show_comment":false,"can_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('61','游客','新闻分类','article_type','新闻分类列表','/article_type/table','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('62','游客','新闻分类','article_type','新闻分类详情','/article_type/view','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('63','注册用户','景点分类','classification_of_scenic_spots','景点分类','/classification_of_scenic_spots/table','','_blank','0','0','0','0','scenic_spot_category','scenic_spot_category','scenic_spot_category',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('64','注册用户','景点分类','classification_of_scenic_spots','景点分类详情','/classification_of_scenic_spots/view','','_blank','0','0','0','0','scenic_spot_category','scenic_spot_category','scenic_spot_category',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('65','注册用户','注册用户','registered_user','注册用户','/registered_user/table','','_blank','0','0','0','0','user_name','user_name','user_name',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('66','注册用户','注册用户','registered_user','注册用户详情','/registered_user/view','','_blank','0','0','0','0','user_name','user_name','user_name',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('67','注册用户','酒店管理','hotel_management','酒店管理','/hotel_management/table','','_blank','0','0','0','0','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{"can_show_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('68','注册用户','酒店管理','hotel_management','酒店管理详情','/hotel_management/view','','_blank','0','0','0','0','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('69','注册用户','酒店管理','hotel_management','酒店管理','/hotel_management/list','top','_blank','1','1','1','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('70','注册用户','酒店管理','hotel_management','酒店管理详情','/hotel_management/details','','_blank','1','1','1','1','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction','hotel_number,hotel_name,layout_of_a_house_or_an_apartment,price,photo,address,amenities,traffic_guide,hotel_introduction',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('71','注册用户','房型管理','room_type_management','房型管理','/room_type_management/table','','_blank','0','0','0','0','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('72','注册用户','房型管理','room_type_management','房型管理详情','/room_type_management/view','','_blank','0','0','0','0','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment','layout_of_a_house_or_an_apartment',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('73','注册用户','旅游路线','tourist_route','旅游路线','/tourist_route/table','','_blank','0','0','0','0','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{"can_show_comment":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('74','注册用户','旅游路线','tourist_route','旅游路线详情','/tourist_route/view','','_blank','0','0','0','0','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('75','注册用户','旅游路线','tourist_route','旅游路线','/tourist_route/list','top','_blank','1','1','1','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('76','注册用户','旅游路线','tourist_route','旅游路线详情','/tourist_route/details','','_blank','1','1','1','1','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction','route_travel,scenic_spot_category,days,cover,price,cost_includes,traffic_strategy,accommodation_strategy,food_introduction,route_introduction',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('77','注册用户','我的收藏','collect','我的收藏','/collect/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('78','注册用户','评论','comment','评论列表','/comment/table','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('79','注册用户','评论','comment','评论详情','/comment/view','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('80','注册用户','评论','comment','我的评论','/comment/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('81','注册用户','评论','comment','评论详情','/comment/details','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('82','注册用户','论坛','forum','攻略交流','/forum/table','','_blank','1','1','1','1','','','',null,'0','{"print":true,"import_db":true,"export_db":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('83','注册用户','论坛','forum','论坛详情','/forum/view','','_blank','1','1','1','1','','','',null,'0','{"print":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('84','注册用户','论坛','forum','攻略交流','/forum/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('85','注册用户','论坛','forum','论坛详情','/forum/details','','_blank','1','1','1','1','','','',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('86','注册用户','论坛分类','forum_type','论坛分类列表','/forum_type/table','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('87','注册用户','论坛分类','forum_type','论坛分类详情','/forum_type/view','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('88','注册用户','新闻','article','新闻列表','/article/table','','_blank','0','0','0','0','','','',null,'0','{"print":false,"import_db":false,"export_db":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('89','注册用户','新闻','article','新闻详情','/article/view','','_blank','0','0','0','0','','','',null,'0','{"print":false}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('90','注册用户','新闻','article','旅游资讯','/article/list','','_blank','1','1','1','1','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('91','注册用户','新闻','article','新闻详情','/article/details','','_blank','1','1','1','1','','','',null,'0','{"can_show_comment":true,"can_comment":true}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('92','注册用户','新闻分类','article_type','新闻分类列表','/article_type/table','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `auth` values ('93','注册用户','新闻分类','article_type','新闻分类详情','/article_type/view','','_blank','0','0','0','0','','','',null,'0','{}',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `user_group` values ('1','100','管理员',null,'','','0',null,"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `user_group` values ('2','100','游客',null,'','','0','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `user_group` values ('3','100','注册用户',null,'registered_user','registered_user_id','0','3',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `slides` values ('1','轮播图1','内容1','/article/details?article=1','/api/upload/image_1615206244747.jpg','558',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `slides` values ('2','轮播图2','内容2','/article/details?article=2','/api/upload/image_1615198875722.jpg','2',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `slides` values ('3','轮播图3','内容3','/article/details?article=3','/api/upload/image_1615206244379.jpg','335',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `slides` values ('4','轮播图4','内容4','/article/details?article=4','/api/upload/image_1615198876367.jpg','483',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `slides` values ('5','轮播图5','内容5','/article/details?article=5','/api/upload/image_1615198876390.jpg','718',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `slides` values ('6','轮播图6','内容6','/article/details?article=6','/api/upload/image_1615206244300.jpg','606',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
insert into `article` values ('1','海兴县取“靠海而兴”之意而命名,自然风景优美,具有多样性','风景','126','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/02f7-kmvwsvy1283541.jpg"></p><p>海兴县隶属沧州市，位于河北省东南，渤海之滨，1965年建县，由山东省无棣、河北省黄骅、盐山三县的边缘贫困乡村合并而成，取“靠海而兴”之意而命名。海兴县地处环渤海经济圈和京津冀都市圈重要位置，邯黄铁路过境建站。海兴县旅游景点有马骝山、海兴湿地、海兴盐田，东汉帝王陵，三姑庙遗址，唐楞严寺，高湾古寺庙群，团山子墓葬群等。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/799/w500h299/20210326/7288-kmvwsvy1283545.jpg"></p><p>01</p><p>马骝山</p><p>马骝山位于河北省海兴县，马骝山南望齐鲁，东临渤海，北倚京津距沧州大港20公里，位于海兴县城东5公里·马骝山又名小山，形成于2--3万年第四纪晚期火山喷发·是九河下梢入海处及九河文化的交汇点。是由火山多期喷发堆积而成，是渤海盆地断裂活动最直接的证据。其典型性、多样性和自然性，实属平原地区独有、国内罕见。是具有重大科学价值和社会价值的地质遗迹区。</p><p>在小山附近先后挖掘出了大量古文物及化石，对研究古代历史文化提供了重要参考价值。从古至今亦留下了一个个凄美动听的故事，山下纵横交错的古栈道、甘甜可口的官井水、能治病的小山沙、茂盛的植物被及原有古塔、古墓、古寺庙等，无一不诉说着小山的神秘。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/508d-kmvwsvy1283544.jpg"></p><p>来到小山，首先听到一个神话传说。说是很早很早以前，这渤海沿岸一带常闹海啸，淹没了庄稼，灌死了牛羊，不知多少人家家破人亡。为解脱这一方人们的危难，天上就派天神下凡，向泰山借山填东海。天神到泰山借了两座山，担起来就向东海而去，当离东海还有二三十公里路时，他感到很累，就换了一下肩。这一换肩可不要紧，由于用劲过猛把扁担颤折。天神担来的这两座山，在西北落地的是小山，在东南落地的是大山(今山东省无棣县境内)。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/11f2-kmvwsvy1283547.jpg"></p><p>这当然是无稽之谈。不过，它寄托了古人的美好愿望。实际上，这小山是在近3万年前地壳运动，火山喷发而形成的产物。小山南北长约7公里，东西宽约1.5公里，主峰海拔36.18米，为沧州之最高点。小山早在属山东省无棣县管辖时，就有“穷大山，富小山，小山有灵又有仙”之说。在夏季，游人进得山来确实如进入仙境一般。</p><p>小山位于县城东十公里处。先秦时称“夹”、“先槛”，秦汉称“柳丘”。隋唐称“峡”、“马骝”，亦称“骝”。历代多俗称“小山”。它形成于三万年前第四纪晚期的火山喷发。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/991f-kmvwsvy1283549.jpg"></p><p>小山一带东临渤海，南望齐鲁，北倚京津，自古为华北平原九河入海处，是九河文化的最终交汇点。早在秦代，始皇嬴政即遣方士徐福率三千童男女由此入海，求长生不老之药。徐福一去不返，始皇乃亲临此地，期盼千童归来。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/126/w640h286/20210326/2fc1-kmvwsvy1283552.jpg"></p><p>02</p><p>海兴湿地</p><p>海兴湿地地处渤海湾西岸，属于河北平原东部运东平原的一部分，总体地势低洼，起伏不大。湿地地貌总趋势为西南部较高，东北部略低，坡降为1.2/15000。海拔（黄海高程）在1.0—3.0米之间。现代地貌的基底是太古代形成的结晶片岩、花岗片麻岩和混合岩。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/146/w640h306/20210326/bdf1-kmvwsvy1283548.jpg"></p><p>海兴湿地区域内部地貌差异较大，由于河道、沟渠纵横交错，形成了微波起伏的地貌特征，主要地貌类型有：</p><p>（1）河流：湿地地势低洼，河流众多。素有“九河下梢”之称的大口河，南部有漳卫新河，中部是宣惠河、淤泥河、大浪淀河，北部是六十六排干渠。</p><p>（2）河间洼地：河床两侧为古河道遗迹，沉积层较厚，较大型的洼地常年积水，有的仅夏季积水，冬春干涸。</p><p>（3）沼泽：杨埕以北宣惠以南地区，原是第四纪以来贝壳和泥沙在海潮的顶抵下沉积下来围成的泻湖。为了排泄和灌溉需要，围堤修筑了2400公顷的水库——杨埕水库。</p><p>（4）山丘：湿地以西有第四纪火山活动遗留下灰的连片分布的低矮山丘，由火山碎屑物质堆积而成，最高处海拔达36米。主要山体有小山（古称马骝山）和磨磨山（也称末末山）。素有“富小山”之称。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/200/w640h360/20210326/439d-kmvwsvy1283554.jpg"></p><p><br></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('2','风景这边独好——沿着高速看中国','风景','602','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>沿着高速看中国</p><p>趁着春光正好</p><p>来一场说走就走的旅行</p><p>沐春光 赏花海</p><p>漫游城镇乡野</p><p>走遍山川湖海</p><p>如在画中穿行</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/308/w554h554/20210325/74ad-kmvwsvx8027849.jpg"></p><p><strong>跨越山海气贯长虹</strong></p><p><strong>包茂国家高速公路渝湘段</strong></p><p><strong>阿蓬江特大桥</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/8c84-kmvwsvx8027856.gif"><strong>阿蓬江特大桥</strong></p><p>横跨在重庆市黔江区阿蓬江大峡谷上</p><p>让昔日天堑变通途</p><p>道通则人兴 路通则民富</p><p>阡陌交通托起人民的小康梦想</p><p><strong>连霍国家高速果子沟大桥</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/239d-kmvwsvx8028049.gif"></p><p><strong>连霍国家高速</strong></p><p>是我国最长的高速公路</p><p>打通了西北、中原及东部沿海</p><p>是著名的亚欧大陆桥通道</p><p><strong>果子沟大桥</strong>上</p><p>汽车在峡谷间巡回漫游</p><p>既有怪石嵯峨、峭壁悬空的险境</p><p>又有开满杏花的茂密山林</p><p>犹如行走在天上云间</p><p>恍入童话仙境</p><p><strong>神州筑梦 大道纵横</strong></p><p><strong>景婺黄高速</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/e20e-kmvwsvx8028051.gif"><strong>景婺黄高速公路</strong></p><p>是杭瑞国家高速公路的重要路段</p><p>沿线风景秀美 风光绮丽</p><p>白墙青瓦的徽派建筑</p><p>漫山遍野的油菜花海</p><p>“五岳归来不看山，黄山归来不看岳”</p><p>无一不在邀请你加入这场</p><p>春的盛宴</p><p><strong>黄黄高速</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/e8ab-kmvwsvx8028283.gif"><strong>湖北省黄黄高速公路</strong></p><p>是沪渝、福银两条国家高速公路的共线路段</p><p>西起黄石长江公路大桥</p><p>止于鄂皖交界的界子墩</p><p>途径浠水 蕲春 武穴 黄梅</p><p>你将路过</p><p>广袤绿洲 万顷良田</p><p>一派春意盎然 生机勃勃</p><p><strong>京新国家高速</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/473c-kmvwsvx8028496.gif"><strong>京新国家高速</strong></p><p>贯穿北京 河北 山西 内蒙古 甘肃 新疆</p><p>迈过高山深谷</p><p>穿越沙漠戈壁</p><p>每次一经过</p><p>让我们更懂山河天地的魅力</p><p><strong>开往春天 锦绣未来</strong></p><p><strong>京昆国家高速公路</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/b2fe-kmvwsvx8028604.gif"><strong>京昆国家高速公路</strong></p><p>从北京出发</p><p>开往彩云之南</p><p>途经河北 山西 陕西 四川</p><p>路上</p><p>一边赏山花烂漫 一边打卡人文胜地</p><p>十渡 晋祠 平遥古镇</p><p>西安古都 秦岭山脉 三星堆</p><p>武侯祠 杜甫草堂 都江堰</p><p>元谋人化石遗址</p><p>感悟文化生生不息</p><p>传承发展</p><p><strong>海南环岛高速</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/c6f7-kmvwsvx8028605.gif"><strong>海南环岛高速公路自建设至今</strong></p><p>仍然是海南路网中最繁忙的</p><p>交通主动脉</p><p>环岛一圈</p><p>天水一色 长滩椰林</p><p>尽赏南国旖旎 海的深沉与浪漫</p><p><strong>拉林高等级公路</strong></p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd2021325s/360/w180h180/20210325/7b83-kmvwsvx8028673.gif"><strong>这条路带你从“日光之城”拉萨</strong></p><p><br></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('3','它是沈从文《边城》的原型，处在三省交界处，风景如画游客不多','风景','809','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>很多人旅游都是为了放松自己紧张的心情，所以很多人都想要找一个风景秀美而且比较僻静的地方，这样不仅可以更好的放松心情，而且还能够增进一同旅行的人的感情，正是因为这样的人多了，所以古镇文化才会慢慢兴起。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/258/w640h418/20210324/766a-kmvwsvx6547318.png"></p><p>地处三省交界</p><p>周边游让古镇文化一度非常火热，很多城市都斥巨资兴建了不少的仿古城，虽然没有古城的古色古香，但是跟平时见到的景色也有很大的不同。很多传承已久的古城也再度散发出了魅力，吸引了不少旅客的游览。</p><p>而在重庆东南部就有一个风景秀丽可是游览人数却不是很多的古镇，这个地方就是洪安古镇。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/256/w640h416/20210324/bb25-kmvwsvx6547323.png"></p><p>古镇介绍</p><p>很多人听到洪安古镇都是一愣，因为重庆的热门景点中很少提及这个古镇，但其实这座古镇却是大有来头，因为是大文豪沈从文的小说《边城》的原型，所以有不少人慕名而来，全镇总面积有52平方公里，所以景点还是不少的。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/257/w640h417/20210324/9a8e-kmvwsvx6547320.png"></p><p>洪安古镇位于湖南、重庆、贵州三个省的交界处，之前是一个三不管的地方，所以经济比较落后，但是后来划入重庆之后得到了快速的发展，镇民们的生活也过的越来越富足，很多游客到这里都可以感受到乡亲们的热情和友善。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/252/w640h412/20210324/44ea-kmvwsvx6547327.png"></p><p>秀美风光</p><p>洪安古镇的自然风光十分秀丽，这里依山傍水气候湿润，成片的绿树让古镇空气十分清新，河水在微风的吹拂下泛起了点点波光，美得就像一幅画一样。</p><p>而且洪安古镇是土家族风格的建筑，由石板铺成的街道配上青砖黑瓦风格的土家族建筑，让人可以感到浓郁的历史气息，不仅沈从文先生描写过这个地方，就连二野大军进入大西南的时候，司令部都在这里驻扎过很长一段时间。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/269/w640h429/20210324/e034-kmvwsvx6547326.png"></p><p>特色美食</p><p>除了特色的风光和历史之外，洪安古镇还有“一锅煮三省”的洪安腌菜鱼，为什么说是一锅煮三省呢？湖南的鱼鲜和贵州的豆腐再加上重庆的腌菜，三省的美食汇聚一锅，才能形成特色的洪安腌菜鱼。三种味道融合成一道菜，你中有我我中有你，不仅鲜辣可口而且相互不冲味，显得十分和谐。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/263/w640h423/20210324/ce96-kmvwsvx6547325.png"></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('4','深圳旅游景点排行','风景','246','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>深圳作为中国的四大一线城市之一，虽然没有北京文化古城的韵味，却有着现代化的时尚感。如果，您打算去深圳旅游，那么，您应该去品牌网小编为您推荐的<span style="color: rgb(51, 51, 51);">几个好看的旅游景点</span>。下面一起来看看<span style="color: rgb(51, 51, 51);">深圳旅游景点排名</span>吧。</p><p><span style="color: rgb(51, 51, 51);"> 一，世界之窗</span></p><p>世界之窗位于深圳湾畔的华侨城内，占地48万平方米。她以弘扬世界文化为宗旨，把世界奇观、历史遗迹、古今名胜、民间歌舞表演汇集一园，以"您给我一天，我给您一个美妙的世界"为号召，营造了一个精彩美妙的世界。世界之窗景区按五大洲划分，与世界广场、世界雕塑园、国际街、侏罗纪天地共同构成千姿万态、美妙绝伦的世界。118个景点按不同比例自由仿建，精巧别致，惟妙惟肖，令游客叹为观止。如果说世界之窗的一个个景点是一首首凝固的交响诗，那么异彩纷呈的民俗表演则是一幅幅活动的风情画。每当华灯初上，在世界广场上演的大型歌舞和狂欢巡游，更是把世界之窗的主题--"世界与您共欢乐"表现得淋漓尽致。</p><p><span style="color: rgb(51, 51, 51);"> 二，野生动物园</span></p><p>野生动物园建于深圳西丽湖畔，占地面积120万平方米，是我国第一家集动物园、植物园、科普园等多种园艺、观赏功能为一体的亚热带新型园林生态环境风景区。园内放养着来自世界各洲的300多个品种、一万多头(只)动物，有不少属于世界珍禽名曾和我国一、二级保护动物。马戏、群象、海豹、鸟类四个表演馆将游客带入一座座神奇、欢乐的世界;还有别具情趣的百鸟乐园、儿童乐园、猴山、鳄鱼湖、水族馆、鹦鹉小径、观景天桥和了望塔等。每日推出的大型动物广场艺术表演是目前世界动物园中绝无仅有的大制作，节目刺激惊险，场面神秘壮观，使人有"体验野性，回归自然"之感。</p><p><span style="color: rgb(51, 51, 51);"> 三，锦绣中华微缩景区</span></p><p>锦绣中华微缩景区坐落在深圳湾畔，是一座反映中国历史、文化艺术、古代建筑和民族风情比较丰富、比较生动、比较全面的微缩景区，占地450亩。景区中，近百处景点大致按中国区域版图分布。这里有名列世界八大奇迹的万里长城、秦陵兵马俑有比较古老的石拱桥，比较大的宫殿和佛像比较大的皇家园林，比较长的石窟画廊，海拔比较高比较宏伟的建筑等众多世界之比较;有肃穆庄严的黄帝陵，金碧辉粕的孔庙，雄伟壮观的泰山，险峻挺拔的长江三峡;还有如诗如画的漓江山水，千姿百态的名塔、名寺、名楼、名石窟以及具有民族风情的地方民居;此外，皇帝祭天、光绪大婚、孔庙祭典的场面与民间婚丧嫁娶风俗尽呈眼前，让游客大饱眼福。使游客"一步迈进历史，一天游遍中国"，它可以称做是中国历史之窗、文化之窗、旅游之窗。</p><p><span style="color: rgb(51, 51, 51);"> 四，中国民俗文化村</span></p><p>中国民俗文化村是国内第一个荟萃各民族民间艺术、民俗风情和居民建筑于一园的大型文化游览区，坐落在深圳湾畔，毗邻锦绣中华微缩景区，占地20万平方米。民俗文化村以"源于生活、高于生活、荟集景区、有所取舍"作为建村的指导原则，从不同角度反映我国民族的民俗文化。景区现有21个民族的24个村寨，均按原景的1：1比例建造。游客在村寨里可以了解民族的建筑风格，还可以欣赏和参与各民族的歌舞表演、民族工艺品制作，品尝民族风味食品，观赏民族艺术广场表演和专业水平的歌舞晚会，欢度民间喜庆节日，领略56个民族多姿多彩的文化艺术。</p><p><span style="color: rgb(51, 51, 51);"> 五，青青世界</span></p><p>青青世界位于深圳大南山的月亮湾畔，占地20万平方米，在这里，自然风情与民族文化相融，精致农业与旅游观光互补，形成一种具有浓厚现代色彩的山林野趣，被誉为"第四代旅游产品"的典范。依山而筑的小木屋供游客小住;园艺馆里，引种培植了来自日本，荷兰等国家和地区的数百种花卉;果园也汇集了十多种果树，常年果实累累。陶艺馆，不但可以领略中国传统的陶艺精品，亦让人们体验自己制作的乐趣;侏罗纪公园，藏卧着大大小小，形态逼真的恐龙和鳄鱼;蝴蝶谷内成群的蝴蝶在游客周围翩翩起舞、上下翻飞;还有充满野趣的露营区、烧烤场、钓鱼池、民艺广场等景点。让人实实在在的跳出城市生活节奏，放松心情去体验自然。</p><p><span style="color: rgb(51, 51, 51);"> 六，仙湖植物园</span></p><p>仙湖植物园是以旅游为主，科研科普为辅的风景植物园，坐落在梧桐山。全园分天上人间、天池、湖区、庙区、沙漠和松柏杜鹃五大景区，建有别有洞天、迷宫、天池、芦汀乡渡、仙渡、玉带桥、逍遥谷、野营区、龙蹲塔、听涛阁、揽胜亭等十几处园林景点和棕榈园、竹区、荫生植物区、沙漠植物区、百果园、水生植物园、裸子植物区、国际苏铁保存中心、盆景园、珍稀树木园等十几个植物专类园，保存的植物达三千多种，还有世界上比较大的化石森林。棕榈区草绿茵茵，林葵树分布其间，呈现出一派浓郁的热带风光;室内观赏植物区内，食虫植物伺机捕食，跳舞兰鲜艳的花朵宛然宫女踩着优美的舞步;晨曦中，弘法寺钟声回响，诵经曲徐疾有致，令人肃穆;夕阳下，湖水波光潋潋，绿树亭倒影其中，景色如画……</p><p><span style="color: rgb(51, 51, 51);"> 七，小梅沙</span></p><p>素有"东方夏威夷"之美誉的著名海滨旅游景区--小梅沙位于深圳东部大鹏湾。小梅沙三面青山环抱，一面海水蔚蓝，一弯新月似的沙滩镶嵌在兰天碧波之间。她的环海沙滩延绵千里，海滨浴场洁净开阔，兰色的大海碧波万顷，茂盛的椰树婆娑起舞。放眼望去，海滨沙滩被鲜艳的太阳伞装点得五彩缤纷，游艇犁出浪花，降落伞迎风绽开，墩洲岛巨浪拍岸，千人烧烤场篝火通红。</p><p>来源 品牌网 转载请注明出处</p>','',null);
insert into `article` values ('5','比较新十大暑假旅游景点排行','风景','678','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>炎热的夏季，暑气逼人，暑期长假即将来临，那么漫漫暑期，到底选择去<span style="color: rgb(51, 51, 51);">什么地方避暑好呢</span>?以下小编为您整理一份<span style="color: rgb(51, 51, 51);">比较新十大暑假旅游景点排行</span>，供您参考。<span style="color: rgb(255, 255, 255);">www.chinapp.com 品牌网</span></p><p><br></p><p class="ql-align-center"><img src="https://img.chinapp.com/uploadfile/2014/0624/20140624113933255.png"></p><p>1、桂林</p><p>理由：桂林地区属岩溶地貌，这些特殊的地貌与景象万千的漓江及其周围美丽迷人的田园风光融为一体，形成了独具一格、驰名中外的“山清、水秀、洞奇、石美”的“桂林山水”。这时的山，平地拔起，千姿百态;漓江的水，蜿蜒曲折，明洁如镜;山多有洞，洞幽景奇，瑰丽壮观;洞中怪石，鬼斧神工，琳琅满目，而自上而下应有“山水甲天下”的赞誉。</p><p>2、长白山</p><p>理由：长白山是风光秀丽、景色迷人的关东第一山，景观绮丽迷人，驰名中外，登上群峰之冠，可谓“一览众山小”!由于山地地形垂直变化的影响，长白山从山脚到山顶，随着调高度的增加形成了由温带到寒带的4个景观带，这在世界上是罕见的，“一山有四季，十里不同天”，在这时可以度过一个不一样的夏季了。</p><p>3、神农架</p><p>理由：神农架冰山位于湖北省，这里有奇特的风洞、雷洞、闪洞、雾洞等自然奇观。其中神秘莫测的冰洞里还有冰柱、冰剑、冰坠、冰塔、冰珠等，千种奇象，万种神态，寒光皎洁，妖娆夺目。如果你喜欢，还可以在这里做一次惊心动魄的漂流。总的来说，在炎炎的夏季来这里感受一份难得的凉爽，是比较好不过的事情了。</p><p>4、庐山</p><p>理由：几千万年前的地壳运动，造就了庐山叠嶂九层、崇岭万仞的赫赫气势，伴生出峰诡不穷、怪石不绝的阳刚之美。由于庐山高耸于江湖之间，雨量丰富，年降水量可达2000毫米，故山中温差大，云雾多，千姿百态，变幻无穷。到庐山旅游，不可不体味庐山的云雾之美。至此消暑，环境幽静，烦热顿消，成为全国著名的避暑胜地。</p><p><br></p><p class="ql-align-center"><img src="https://img.chinapp.com/uploadfile/2014/0624/20140624113955479.png"></p><p>5、乌镇</p><p>理由：乌镇是一个历史悠久，文化氛围浓郁的水乡古镇。这时除了具备小桥、流水、人家的水乡风情和精巧雅致的民居建筑之外，更多地飘逸着一股浓郁的历史和文化气息。在这座小镇，历史上曾出过64个进士，161个举人。现代中国的文学巨匠DD茅盾，也诞生在这个小镇上。</p><p>6、承德避暑山庄</p><p>理由：承德位于湖北省东北部，这里山环水绕，林木苍郁，风景秀丽，气候宜人。我国比较大的古典皇家园林“避暑山庄”和大型寺庙群“外八庙”就坐落在市区北新半部。整个山庄殿宇巍峨，丁朴典雅;明湖百倾，洲岛错落;平川旷野，芳草如茵;山峦苍翠，林木葱郁，很是凉爽。</p><p>7、北戴河</p><p>理由：北戴河 位于河北省秦皇岛市西南，南临渤海，北靠联峰山，海滩漫长曲折，沙软潮平，林木苍翠，水面凉气轻拂，是著名的海滨避暑胜地。盛夏季节，这里气候宜人，游人置身其间，心旷神怡，暑气皆消。</p><p><br></p><p class="ql-align-center"><img src="https://img.chinapp.com/uploadfile/2014/0624/20140624114022875.png"></p><p>8.安徽黄山</p><p>理由：安徽,世界文化与自然遗产,世界地质公园,三山五岳中三山之一,国家5A级风景区,著名避暑胜地</p><p>9.九寨沟-黄龙</p><p>理由：四川,世界自然遗产,国家5A级风景区,国家森林公园,全国重点风景名胜区,中国十大风景名胜区</p><p>10.苏州园林</p><p>理由：世界文化与自然遗产,拙政园/留园/网狮园/环秀山庄等,中国古典园林建筑的典范,国家5A级旅游景区</p><p>来源 品牌网 chinapp.com 转载请注明出处</p>','',null);
insert into `article` values ('6','广西这座中越边境小城,素有“风景小桂林”之称,却少有人知','风景','245','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>广西是一个美丽的地方，对于没去过的人，广西就是一个梦幻的美梦，充满了期待。特别是桂林，素来就有“桂林山水甲天下之说，相信大家去广西旅游的时候，大多数人还是首选桂林。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/168/w606h362/20210325/1958-kmvwsvx7590076.jpg"></p><p>但除了桂林之外，你知道在广西西部毗邻云南和越南的山水间，还有一座宛如世外桃源般的小城吗？它有不输桂林的清泉，颜色时蓝时绿，令人心醉。这里青山环绕，田园如画，它就是地处中越边境的靖西市，</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/197/w626h371/20210325/42e4-kmvwsvx7590081.jpg"></p><p>靖西地处桂西南边陲，边境线绵长，是一个典型的壮族聚居县，也是中国境内一处充满诱惑和魅力的边关旅游胜地。在这里，游客不仅能感受边境风情，加上这里夏无酷暑，冬无严寒，年均气温19.1℃。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/204/w630h374/20210325/535e-kmvwsvx7590086.jpg"></p><p>所以靖西一直以四季如春的自然风光闻名遐迩，素有“山水似桂林，气候胜昆明”的美誉。这里有一步一景的美丽峡谷—通灵大峡谷，结合了热带雨林、河流瀑布、峡谷溶洞等多种景观的自然风景区，也是靖西最著名的景点之一，被称为“地球上一道美丽的伤痕”。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/184/w621h363/20210325/2728-kmvwsvx7590082.jpg"></p><p>而通灵大峡谷最壮丽的景观，是高168米、宽30米的中国落差最大的瀑布——通灵大瀑布。位于一处地缝边缘，水流从崖顶凌空而下，飞溅到数百米外，让游人难以靠近。当你沿着栈道还可以走到山壁内部溶洞，瀑布轰隆声震耳欲聋，</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/192/w624h368/20210325/7ed3-kmvwsvx7590079.jpg"></p><p>位于市区南约5公里的鹅泉，也是靖西最有名的景点之一，它与大理蝴蝶泉、桂林西山乳泉并称为中国西南三大名泉。这里的水绿得让人心动，像是一块翡翠。周边翠峰如屏。田园似锦，景色如画，正是陶渊明笔下的田园生活模样。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/187/w621h366/20210325/de2c-kmvwsvx7590078.jpg"></p><p>据记载，明成化六年(1470)年，嘉靖皇帝得知鹅泉山川灵秀，于是赐名“灵泉晚照”，因而鹅泉又被称为灵泉。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/186/w621h365/20210325/fe5f-kmvwsvx7590083.jpg"></p><p>沿着鹅泉下游开车15分钟，便可到达有“壮族活的博物馆”之称的旧州古镇。旧州古称“那签”，历史可追溯700多年前的南宋，是明朝著名抗倭女老英雄瓦氏夫人的故乡。荟萃了壮族建筑文化、宗教文化和土司文化。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/170/w606h364/20210325/6935-kmvwsvx7590088.jpg"></p><p>这里有全国闻名的绣球一条街，依河而建，石板地面，两边有众多古建筑，大青砖，厚木门。在这里你会发现每家每户的门口，旧州的壮族绣娘仍旧一针一线地缝制绣球。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/204/w631h373/20210325/383a-kmvwsvx7590077.jpg"></p><p>在靖西，除了以上知名景点外，还有很多值得一去的地方，比如古龙山峡谷漂流、巴泽梯田、渠洋湖、爱布村等。当然，如果想去靖西旅游，自驾游可能是到靖西旅游最好的交通方式，因为在广西南部的山水之间，隐藏着一条“世界最美公路”。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/207/w630h377/20210325/0692-kmvwsvx7590084.jpg"></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('7','深圳旅游景点排行','风景','316','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>深圳作为中国的四大一线城市之一，虽然没有北京文化古城的韵味，却有着现代化的时尚感。如果，您打算去深圳旅游，那么，您应该去品牌网小编为您推荐的<span style="color: rgb(51, 51, 51);">几个好看的旅游景点</span>。下面一起来看看<span style="color: rgb(51, 51, 51);">深圳旅游景点排名</span>吧。</p><p><span style="color: rgb(51, 51, 51);"> 一，世界之窗</span></p><p>世界之窗位于深圳湾畔的华侨城内，占地48万平方米。她以弘扬世界文化为宗旨，把世界奇观、历史遗迹、古今名胜、民间歌舞表演汇集一园，以"您给我一天，我给您一个美妙的世界"为号召，营造了一个精彩美妙的世界。世界之窗景区按五大洲划分，与世界广场、世界雕塑园、国际街、侏罗纪天地共同构成千姿万态、美妙绝伦的世界。118个景点按不同比例自由仿建，精巧别致，惟妙惟肖，令游客叹为观止。如果说世界之窗的一个个景点是一首首凝固的交响诗，那么异彩纷呈的民俗表演则是一幅幅活动的风情画。每当华灯初上，在世界广场上演的大型歌舞和狂欢巡游，更是把世界之窗的主题--"世界与您共欢乐"表现得淋漓尽致。</p><p><span style="color: rgb(51, 51, 51);"> 二，野生动物园</span></p><p>野生动物园建于深圳西丽湖畔，占地面积120万平方米，是我国第一家集动物园、植物园、科普园等多种园艺、观赏功能为一体的亚热带新型园林生态环境风景区。园内放养着来自世界各洲的300多个品种、一万多头(只)动物，有不少属于世界珍禽名曾和我国一、二级保护动物。马戏、群象、海豹、鸟类四个表演馆将游客带入一座座神奇、欢乐的世界;还有别具情趣的百鸟乐园、儿童乐园、猴山、鳄鱼湖、水族馆、鹦鹉小径、观景天桥和了望塔等。每日推出的大型动物广场艺术表演是目前世界动物园中绝无仅有的大制作，节目刺激惊险，场面神秘壮观，使人有"体验野性，回归自然"之感。</p><p><span style="color: rgb(51, 51, 51);"> 三，锦绣中华微缩景区</span></p><p>锦绣中华微缩景区坐落在深圳湾畔，是一座反映中国历史、文化艺术、古代建筑和民族风情比较丰富、比较生动、比较全面的微缩景区，占地450亩。景区中，近百处景点大致按中国区域版图分布。这里有名列世界八大奇迹的万里长城、秦陵兵马俑有比较古老的石拱桥，比较大的宫殿和佛像比较大的皇家园林，比较长的石窟画廊，海拔比较高比较宏伟的建筑等众多世界之比较;有肃穆庄严的黄帝陵，金碧辉粕的孔庙，雄伟壮观的泰山，险峻挺拔的长江三峡;还有如诗如画的漓江山水，千姿百态的名塔、名寺、名楼、名石窟以及具有民族风情的地方民居;此外，皇帝祭天、光绪大婚、孔庙祭典的场面与民间婚丧嫁娶风俗尽呈眼前，让游客大饱眼福。使游客"一步迈进历史，一天游遍中国"，它可以称做是中国历史之窗、文化之窗、旅游之窗。</p><p><span style="color: rgb(51, 51, 51);"> 四，中国民俗文化村</span></p><p>中国民俗文化村是国内第一个荟萃各民族民间艺术、民俗风情和居民建筑于一园的大型文化游览区，坐落在深圳湾畔，毗邻锦绣中华微缩景区，占地20万平方米。民俗文化村以"源于生活、高于生活、荟集景区、有所取舍"作为建村的指导原则，从不同角度反映我国民族的民俗文化。景区现有21个民族的24个村寨，均按原景的1：1比例建造。游客在村寨里可以了解民族的建筑风格，还可以欣赏和参与各民族的歌舞表演、民族工艺品制作，品尝民族风味食品，观赏民族艺术广场表演和专业水平的歌舞晚会，欢度民间喜庆节日，领略56个民族多姿多彩的文化艺术。</p><p><span style="color: rgb(51, 51, 51);"> 五，青青世界</span></p><p>青青世界位于深圳大南山的月亮湾畔，占地20万平方米，在这里，自然风情与民族文化相融，精致农业与旅游观光互补，形成一种具有浓厚现代色彩的山林野趣，被誉为"第四代旅游产品"的典范。依山而筑的小木屋供游客小住;园艺馆里，引种培植了来自日本，荷兰等国家和地区的数百种花卉;果园也汇集了十多种果树，常年果实累累。陶艺馆，不但可以领略中国传统的陶艺精品，亦让人们体验自己制作的乐趣;侏罗纪公园，藏卧着大大小小，形态逼真的恐龙和鳄鱼;蝴蝶谷内成群的蝴蝶在游客周围翩翩起舞、上下翻飞;还有充满野趣的露营区、烧烤场、钓鱼池、民艺广场等景点。让人实实在在的跳出城市生活节奏，放松心情去体验自然。</p><p><span style="color: rgb(51, 51, 51);"> 六，仙湖植物园</span></p><p>仙湖植物园是以旅游为主，科研科普为辅的风景植物园，坐落在梧桐山。全园分天上人间、天池、湖区、庙区、沙漠和松柏杜鹃五大景区，建有别有洞天、迷宫、天池、芦汀乡渡、仙渡、玉带桥、逍遥谷、野营区、龙蹲塔、听涛阁、揽胜亭等十几处园林景点和棕榈园、竹区、荫生植物区、沙漠植物区、百果园、水生植物园、裸子植物区、国际苏铁保存中心、盆景园、珍稀树木园等十几个植物专类园，保存的植物达三千多种，还有世界上比较大的化石森林。棕榈区草绿茵茵，林葵树分布其间，呈现出一派浓郁的热带风光;室内观赏植物区内，食虫植物伺机捕食，跳舞兰鲜艳的花朵宛然宫女踩着优美的舞步;晨曦中，弘法寺钟声回响，诵经曲徐疾有致，令人肃穆;夕阳下，湖水波光潋潋，绿树亭倒影其中，景色如画……</p><p><span style="color: rgb(51, 51, 51);"> 七，小梅沙</span></p><p>素有"东方夏威夷"之美誉的著名海滨旅游景区--小梅沙位于深圳东部大鹏湾。小梅沙三面青山环抱，一面海水蔚蓝，一弯新月似的沙滩镶嵌在兰天碧波之间。她的环海沙滩延绵千里，海滨浴场洁净开阔，兰色的大海碧波万顷，茂盛的椰树婆娑起舞。放眼望去，海滨沙滩被鲜艳的太阳伞装点得五彩缤纷，游艇犁出浪花，降落伞迎风绽开，墩洲岛巨浪拍岸，千人烧烤场篝火通红。</p><p>来源 品牌网 转载请注明出处</p>','',null);
insert into `article` values ('8','松滋市是一座集工业农业商贸旅游于一体的新兴城市,风景也很美','风景','27','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/4/w534h270/20210325/e6cf-kmvwsvy0000730.jpg"></p><p>松滋市位于湖北省西南部，处于平原和丘陵结合地区，隶属荆州市管辖。是一座集工业农业商贸旅游于一体的新兴城市。2015年被列为第二批国家新型城镇化综合试点地区。2019年3月，被列为第一批革命文物保护利用片区分县名单。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/222/w640h382/20210325/18c8-kmvwsvy0000735.jpg"></p><p>01</p><p>洈水风景区</p><p>洈水水库属亚洲著名的人工淡水湖，洈水大坝全长8968米，属亚洲第一大人工型土坝。湖水浩淼碧澄，天水一色，500个湖心岛在水中崛起，使水面多处分割，几经收放，形成连续的风景区域，湖中有岛，岛中有湖，湖光山色尽在其中；500个半岛群峰毗连，层峦叠嶂，山水相依，可谓"山得水而活，水得山而媚"。有"楚南仙境千岛湖"之美誉。</p><p>洈水森林公园总面积52.8平方公里，森林覆盖率达80%以上，林中无处不飞花，山间处处有芳草，生态环境良好，野生动物资源丰富。春花、夏树、秋月、冬雪，四季美景使森林公园成为天地间最宽敞亮丽的泼墨山水。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/164/w640h324/20210325/a1f9-kmvwsvy0000731.jpg"></p><p>洈水汽车露营地，是集户外运动、观光旅游、休闲养生、度假居住为一体的全国首个五星级汽车自驾运动营地。获露营行业最高奖“鹿鹰奖”。营地依托洈水国家水利风景区森林、湿地、岛屿等多样化自然特色条件，在洈水大坝下的丛林中依势而建，以丛林为主题风格，强化人与自然环境互动。占地407亩（21,193平方米），规划分为主会场区、主营区、特色住宿区、活动娱乐区、配套服务区等五个主体功能区。</p><p>主会场区包括丛林广场和舞台。主营区包括：房车营位区、自驾车营位区、露营帐篷区和商业帐篷区。特色住宿区拥有5个房车花园酒店、15个自驾宝、15间童话主题树屋、5间丛林木屋、5个观星帐篷、4个亲水野奢帐篷等个性化住宿产品。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/224/w640h384/20210325/f780-kmvwsvy0000734.jpg"></p><p>活动娱乐区分为，家庭活动区，包括丛林探险乐园、儿童乐园、戏水池、采摘园。</p><p>运动区，包括笼式足球、攻略箭、垂钓、攀岩、卡丁车等；团建区，包括空中华容道（高低空探险）、丛林野战乐园、过五关斩六将（团队拓展基地）。配套服务区有游客服务中心、淋浴房、洗衣房和卫生间、书吧、茶吧、简餐厅等。</p><p>滤去城市的喧嚣，回归自然的宁静，洈水假日汽车营地将带给您一个亲近自然的时尚、欢乐、放松的浪漫体验。</p><p>洈水湖有500多座岛屿分布在湖四周，有着“楚南仙境千岛湖”之美誉，它们时伸时缩，使湖岸蜿蜒曲折，港汊交错，形成山重水复的美丽风光。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/223/w640h383/20210325/46d9-kmvwsvy0000736.jpg"></p><p>“百岛画廊”位于无数个岛屿之中，仿佛在“水上迷宫”中穿行，也仿佛进入一幅绝妙淡雅的水墨丹青画图中。</p><p>李家河生态岛的春、夏、秋、冬园四季瓜果飘香；白云古渡、白云阁、新神洞，神话传说、历史风云与奇山异水相得益彰。到岛上露营驿站感受幕天席地、枕水听涛的岛上露营，体会李白诗中“飞羽觞而醉月，开琼筵以坐花”的情景，更是别有一番风味。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/139/w640h299/20210325/05eb-kmvwsvy0000737.jpg"></p><p>新神洞以"洞中瀑布"、"边石坝"、"乾坤神柱"、"天宫大幕"等绝景著称"天下第一奇洞"。颜将军洞、古神洞等10多个溶洞奇石叠垒，洞幽玲珑，令人叹为观止。</p><p>02</p><p>言程公园</p><p>言程公园位于湖北省松滋市市区西北方向，由金松大道、贺炳炎大道和环湖路围合而成。东接环湖路，南邻市民中心政府办公大楼，西连贺炳炎大道，北临金松大道，四面环路、路路相通。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/164/w640h324/20210325/057b-kmvwsvy0000732.jpg"></p><p><br></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('9','驻马店：这里风景如画','风景','52','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p><strong>天中晚报全媒体记者&nbsp;王建成</strong></p><p><br></p><p><img src="https://n.sinaimg.cn/sinakd10118/360/w720h440/20210325/28e4-kmvwsvy0072477.jpg"></p><p>3月25日，市练江河西段，两岸的油菜花盛开，让人流连忘返。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/89/w720h969/20210325/e061-kmvwsvy0072896.jpg"></p><p>一名市民驾驶橡皮船一边欣赏美丽的风景，一边在河中撒网捕鱼。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/370/w720h450/20210325/44e5-kmvwsvy0072891.jpg"></p><p>初春的小河边，金黄的油菜花与悠然自得捕鱼的市民相映成趣。</p><p><img src="http://n.sinaimg.cn/sinakd20210325ac/364/w720h444/20210325/d3d8-kmvwsvy0072875.jpg"></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('10','有“广东最美湖泊”之称,还曾登上小学课本,风景优美却鲜少人知','风景','88','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p>说起广东，大家肯定不会陌生，作为我国经济最发达的省份，境内很多城市都家喻户晓，而随着近几年来我国旅游业的兴起，越来越多游客也来到了广东旅游，不过，大家所观光的，无非就是像广州、珠海此类的大城市，殊不知，在广东境内，还藏有一个美丽的湖北，它有“广东最美湖泊”的美誉，同时还登上过小学课本，风景优美却鲜少人知。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/272/w640h432/20210324/dc34-kmvwsvx6922641.jpg"></p><p>这座湖泊就是湖光岩风景区，想必很多广东的朋友都或多或少听说过，它地处于湛江市区西南18公里处，总面积达38平方公里，是一座以玛珥火山地质地貌为主体的自然生态公园，境内由雷琼世界地质公园博物馆、楞严寺、李纲醉月雕像、美食欢乐园、清风林、火山地质遗迹、白牛仙女雕像等20个景点组成的4A级国家景区。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/272/w640h432/20210324/598a-kmvwsvx6922649.jpg"></p><p>很多人都以为湖光岩风景区是一座现代所建造的风景区，其实不然，景区内有很多景点都是古代所建，例如依岩而建的楞严寺，就是始建于隋代末年，同时还是全国十八大古刹之一，还有宋朝所建的白衣庵，就连景区的名字，也是宋朝丞相李纲所起。当时正值金军犯境，李纲作为宋朝抗金名将，与奸臣秦桧不合，所以被其所害，被贬海南，在路途中看到了此地，于是便在摩崖石上刻下了“湖光岩”。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/272/w640h432/20210324/7fd9-kmvwsvx6922647.jpg"></p><p>而湖光岩风景区是在2001年才正式对外开放，其中最具代表性的景点就是玛珥湖，玛珥湖是距今14—16万年前由平地火山爆炸后冷却下沉形成的玛珥式火山湖，湖深400多米，由于四周被山体包围，常年不受外界干扰，所以湖底有很多具有历史价值的样本。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/270/w640h430/20210324/a103-kmvwsvx6922645.jpg"></p><p>其次还有龙鱼神龟，想必很多人都在景区之中见到过这两尊雕像，而这两座雕像并不是平白无故建立在此的，传说在1998年的5月28日，国防大学将军班在游览景区时，发现了传说中4米多长的龙鱼和近2米宽的大龟遨游湖中的奇观，并且有60人看见，在此之后陆续又有很多人看到这一奇观，景区也为此在东门广场修建龙鱼神龟雕像。</p><p><img src="http://n.sinaimg.cn/sinakd20210324ac/272/w640h432/20210324/a8d8-kmvwsvx6922650.jpg"></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('11','海兴县取“靠海而兴”之意而命名,自然风景优美,具有多样性','风景','775','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/02f7-kmvwsvy1283541.jpg"></p><p>海兴县隶属沧州市，位于河北省东南，渤海之滨，1965年建县，由山东省无棣、河北省黄骅、盐山三县的边缘贫困乡村合并而成，取“靠海而兴”之意而命名。海兴县地处环渤海经济圈和京津冀都市圈重要位置，邯黄铁路过境建站。海兴县旅游景点有马骝山、海兴湿地、海兴盐田，东汉帝王陵，三姑庙遗址，唐楞严寺，高湾古寺庙群，团山子墓葬群等。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/799/w500h299/20210326/7288-kmvwsvy1283545.jpg"></p><p>01</p><p>马骝山</p><p>马骝山位于河北省海兴县，马骝山南望齐鲁，东临渤海，北倚京津距沧州大港20公里，位于海兴县城东5公里·马骝山又名小山，形成于2--3万年第四纪晚期火山喷发·是九河下梢入海处及九河文化的交汇点。是由火山多期喷发堆积而成，是渤海盆地断裂活动最直接的证据。其典型性、多样性和自然性，实属平原地区独有、国内罕见。是具有重大科学价值和社会价值的地质遗迹区。</p><p>在小山附近先后挖掘出了大量古文物及化石，对研究古代历史文化提供了重要参考价值。从古至今亦留下了一个个凄美动听的故事，山下纵横交错的古栈道、甘甜可口的官井水、能治病的小山沙、茂盛的植物被及原有古塔、古墓、古寺庙等，无一不诉说着小山的神秘。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/508d-kmvwsvy1283544.jpg"></p><p>来到小山，首先听到一个神话传说。说是很早很早以前，这渤海沿岸一带常闹海啸，淹没了庄稼，灌死了牛羊，不知多少人家家破人亡。为解脱这一方人们的危难，天上就派天神下凡，向泰山借山填东海。天神到泰山借了两座山，担起来就向东海而去，当离东海还有二三十公里路时，他感到很累，就换了一下肩。这一换肩可不要紧，由于用劲过猛把扁担颤折。天神担来的这两座山，在西北落地的是小山，在东南落地的是大山(今山东省无棣县境内)。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/11f2-kmvwsvy1283547.jpg"></p><p>这当然是无稽之谈。不过，它寄托了古人的美好愿望。实际上，这小山是在近3万年前地壳运动，火山喷发而形成的产物。小山南北长约7公里，东西宽约1.5公里，主峰海拔36.18米，为沧州之最高点。小山早在属山东省无棣县管辖时，就有“穷大山，富小山，小山有灵又有仙”之说。在夏季，游人进得山来确实如进入仙境一般。</p><p>小山位于县城东十公里处。先秦时称“夹”、“先槛”，秦汉称“柳丘”。隋唐称“峡”、“马骝”，亦称“骝”。历代多俗称“小山”。它形成于三万年前第四纪晚期的火山喷发。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/37/w500h337/20210326/991f-kmvwsvy1283549.jpg"></p><p>小山一带东临渤海，南望齐鲁，北倚京津，自古为华北平原九河入海处，是九河文化的最终交汇点。早在秦代，始皇嬴政即遣方士徐福率三千童男女由此入海，求长生不老之药。徐福一去不返，始皇乃亲临此地，期盼千童归来。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/126/w640h286/20210326/2fc1-kmvwsvy1283552.jpg"></p><p>02</p><p>海兴湿地</p><p>海兴湿地地处渤海湾西岸，属于河北平原东部运东平原的一部分，总体地势低洼，起伏不大。湿地地貌总趋势为西南部较高，东北部略低，坡降为1.2/15000。海拔（黄海高程）在1.0—3.0米之间。现代地貌的基底是太古代形成的结晶片岩、花岗片麻岩和混合岩。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/146/w640h306/20210326/bdf1-kmvwsvy1283548.jpg"></p><p>海兴湿地区域内部地貌差异较大，由于河道、沟渠纵横交错，形成了微波起伏的地貌特征，主要地貌类型有：</p><p>（1）河流：湿地地势低洼，河流众多。素有“九河下梢”之称的大口河，南部有漳卫新河，中部是宣惠河、淤泥河、大浪淀河，北部是六十六排干渠。</p><p>（2）河间洼地：河床两侧为古河道遗迹，沉积层较厚，较大型的洼地常年积水，有的仅夏季积水，冬春干涸。</p><p>（3）沼泽：杨埕以北宣惠以南地区，原是第四纪以来贝壳和泥沙在海潮的顶抵下沉积下来围成的泻湖。为了排泄和灌溉需要，围堤修筑了2400公顷的水库——杨埕水库。</p><p>（4）山丘：湿地以西有第四纪火山活动遗留下灰的连片分布的低矮山丘，由火山碎屑物质堆积而成，最高处海拔达36米。主要山体有小山（古称马骝山）和磨磨山（也称末末山）。素有“富小山”之称。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210326ac/200/w640h360/20210326/439d-kmvwsvy1283554.jpg"></p><p><br></p>','','2022年03月23日 12:51 新浪网');
insert into `article` values ('12','松滋市是一座集工业农业商贸旅游于一体的新兴城市,风景也很美','风景','398','0',"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ",null,null,null,'<p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/4/w534h270/20210325/e6cf-kmvwsvy0000730.jpg"></p><p>松滋市位于湖北省西南部，处于平原和丘陵结合地区，隶属荆州市管辖。是一座集工业农业商贸旅游于一体的新兴城市。2015年被列为第二批国家新型城镇化综合试点地区。2019年3月，被列为第一批革命文物保护利用片区分县名单。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/222/w640h382/20210325/18c8-kmvwsvy0000735.jpg"></p><p>01</p><p>洈水风景区</p><p>洈水水库属亚洲著名的人工淡水湖，洈水大坝全长8968米，属亚洲第一大人工型土坝。湖水浩淼碧澄，天水一色，500个湖心岛在水中崛起，使水面多处分割，几经收放，形成连续的风景区域，湖中有岛，岛中有湖，湖光山色尽在其中；500个半岛群峰毗连，层峦叠嶂，山水相依，可谓"山得水而活，水得山而媚"。有"楚南仙境千岛湖"之美誉。</p><p>洈水森林公园总面积52.8平方公里，森林覆盖率达80%以上，林中无处不飞花，山间处处有芳草，生态环境良好，野生动物资源丰富。春花、夏树、秋月、冬雪，四季美景使森林公园成为天地间最宽敞亮丽的泼墨山水。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/164/w640h324/20210325/a1f9-kmvwsvy0000731.jpg"></p><p>洈水汽车露营地，是集户外运动、观光旅游、休闲养生、度假居住为一体的全国首个五星级汽车自驾运动营地。获露营行业最高奖“鹿鹰奖”。营地依托洈水国家水利风景区森林、湿地、岛屿等多样化自然特色条件，在洈水大坝下的丛林中依势而建，以丛林为主题风格，强化人与自然环境互动。占地407亩（21,193平方米），规划分为主会场区、主营区、特色住宿区、活动娱乐区、配套服务区等五个主体功能区。</p><p>主会场区包括丛林广场和舞台。主营区包括：房车营位区、自驾车营位区、露营帐篷区和商业帐篷区。特色住宿区拥有5个房车花园酒店、15个自驾宝、15间童话主题树屋、5间丛林木屋、5个观星帐篷、4个亲水野奢帐篷等个性化住宿产品。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/224/w640h384/20210325/f780-kmvwsvy0000734.jpg"></p><p>活动娱乐区分为，家庭活动区，包括丛林探险乐园、儿童乐园、戏水池、采摘园。</p><p>运动区，包括笼式足球、攻略箭、垂钓、攀岩、卡丁车等；团建区，包括空中华容道（高低空探险）、丛林野战乐园、过五关斩六将（团队拓展基地）。配套服务区有游客服务中心、淋浴房、洗衣房和卫生间、书吧、茶吧、简餐厅等。</p><p>滤去城市的喧嚣，回归自然的宁静，洈水假日汽车营地将带给您一个亲近自然的时尚、欢乐、放松的浪漫体验。</p><p>洈水湖有500多座岛屿分布在湖四周，有着“楚南仙境千岛湖”之美誉，它们时伸时缩，使湖岸蜿蜒曲折，港汊交错，形成山重水复的美丽风光。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/223/w640h383/20210325/46d9-kmvwsvy0000736.jpg"></p><p>“百岛画廊”位于无数个岛屿之中，仿佛在“水上迷宫”中穿行，也仿佛进入一幅绝妙淡雅的水墨丹青画图中。</p><p>李家河生态岛的春、夏、秋、冬园四季瓜果飘香；白云古渡、白云阁、新神洞，神话传说、历史风云与奇山异水相得益彰。到岛上露营驿站感受幕天席地、枕水听涛的岛上露营，体会李白诗中“飞羽觞而醉月，开琼筵以坐花”的情景，更是别有一番风味。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/139/w640h299/20210325/05eb-kmvwsvy0000737.jpg"></p><p>新神洞以"洞中瀑布"、"边石坝"、"乾坤神柱"、"天宫大幕"等绝景著称"天下第一奇洞"。颜将军洞、古神洞等10多个溶洞奇石叠垒，洞幽玲珑，令人叹为观止。</p><p>02</p><p>言程公园</p><p>言程公园位于湖北省松滋市市区西北方向，由金松大道、贺炳炎大道和环湖路围合而成。东接环湖路，南邻市民中心政府办公大楼，西连贺炳炎大道，北临金松大道，四面环路、路路相通。</p><p class="ql-align-center"><img src="http://n.sinaimg.cn/sinakd20210325ac/164/w640h324/20210325/057b-kmvwsvy0000732.jpg"></p><p><br></p>','','2022年03月23日 12:51 新浪网');
insert into `article_type` values ('1','100','风景','0',null,null,null,"2022-04-02 02:18:16.000 ","2022-04-02 02:18:16.000 ");
