package com.project.demo.service;

import com.project.demo.entity.Collect;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 收藏：(Collect)表服务接口
 *
 */
@Service
public class CollectService extends BaseService<Collect> {

}


