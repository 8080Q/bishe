package com.project.demo.service;

import com.project.demo.entity.NavAdmin;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * (NavAdmin)表服务接口
 *
 */
@Service
public class NavAdminService extends BaseService<NavAdmin> {

}


