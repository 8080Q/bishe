package com.project.demo.service;

import com.project.demo.entity.Hits;
import com.project.demo.service.base.BaseService;
import org.springframework.stereotype.Service;

/**
 * 点赞：(Praise)表服务接口
 */
@Service
public class HitsService extends BaseService<Hits> {

}


