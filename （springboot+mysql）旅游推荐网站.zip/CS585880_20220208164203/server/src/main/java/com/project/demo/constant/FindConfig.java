package com.project.demo.constant;

/**
 */
public class FindConfig {

    public static String PAGE = "page";
    public static String SIZE = "size";
    public static String LIKE = "like";
    public static String ORDER_BY = "orderby";
    public static String FIELD = "field";
    public static String GROUP_BY = "groupby";
    public static String MIN_ = "_min";
    public static String MAX_ = "_max";
}
